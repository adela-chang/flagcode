<?php include 'header.php'; ?>

<div style="margin-top:75px">
<p><font style="color:red"><b>Welcome</b></font> to the demo area of Capture the Flag, a game meant to be played on your mobile phone!</p>
<p>Feel free to test out any of the <font style="color:blue"><b>demos</b></font> to the left. Note that the login simulation requires an account to be made and verified on the registration simulation first.</p>
</div>

<?php include 'footer.php'; ?>